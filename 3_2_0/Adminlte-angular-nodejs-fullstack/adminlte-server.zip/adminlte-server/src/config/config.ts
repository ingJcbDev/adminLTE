export default {

    jwtSecret: 'esteEsMiTokenSecreto'
  
  }