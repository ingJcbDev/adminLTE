import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nopage-found',
  templateUrl: './nopage-found.component.html',
  styles: [
  ]
})
export class NopageFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
